Content
Parsers: [SuricataAlerts]
Fields: [SuricataSignature, SuricataSignatureID, flow.bytes_toserver, flow.nbytes_toclient, flow.pkts_toclient, flow.pkts_toserver]

Reference
Fields: [actn, cat, destip, destport, eventtype, flowid, if, mbody, srcip, srcport, tranprot]
